from flask import Flask, render_template, session
from flasgger import Swagger
from models import init_db
from routes.feedback import feedback_bp
from routes.admin import admin_bp
from routes.shop import shop_bp
from routes.api import api_bp

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Необхідно для роботи з сесіями

# Конфігурація Swagger
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'apispec',
            "route": '/apispec.json',
            "rule_filter": lambda rule: True,
            "model_filter": lambda tag: True,
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/api/docs"
}

swagger_template = {
    "info": {
        "title": "Flask Shop API",
        "description": "API для інтернет-магазину з керуванням продуктами, замовленнями та відгуками",
        "version": "1.0.0"
    },
    "tags": [
        {
            "name": "Products",
            "description": "Операції з продуктами"
        },
        {
            "name": "Orders",
            "description": "Операції з замовленнями"
        },
        {
            "name": "Feedback",
            "description": "Операції з відгуками"
        }
    ]
}

swagger = Swagger(app, config=swagger_config, template=swagger_template)

# Ініціалізація бази даних
init_db()

# Реєстрація блюпрінтів
app.register_blueprint(feedback_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(shop_bp)
app.register_blueprint(api_bp)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)
